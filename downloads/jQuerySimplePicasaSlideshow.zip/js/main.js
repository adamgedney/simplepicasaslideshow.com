$(function(){




$('.picasagallery').picasa_slideshow({
	username: 'calaquendidolls',
	album: 'PicasaKittensDayitaAugustus',
	speed: '5000'
});







});// function